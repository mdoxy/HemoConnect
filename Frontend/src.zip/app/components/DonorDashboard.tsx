import { MapPin, Clock, Droplet, AlertCircle, Phone, Navigation, CheckCircle, Users } from 'lucide-react';

interface User {
  name: string;
  role: 'donor' | 'requestor' | 'hospital' | null;
  verified: boolean;
  bloodType?: string;
}

interface DonorDashboardProps {
  user: User | null;
}

interface BloodRequest {
  id: string;
  patientName: string;
  bloodType: string;
  unitsNeeded: number;
  urgency: 'critical' | 'high' | 'normal';
  hospital: string;
  distance: string;
  timeAgo: string;
  location: string;
  compatible: boolean;
}

const mockRequests: BloodRequest[] = [
  {
    id: '1',
    patientName: 'Sarah Johnson',
    bloodType: 'O+',
    unitsNeeded: 2,
    urgency: 'critical',
    hospital: 'City General Hospital',
    distance: '1.2 km',
    timeAgo: '5 min ago',
    location: 'Downtown Medical Center',
    compatible: true,
  },
  {
    id: '2',
    patientName: 'Michael Chen',
    bloodType: 'A+',
    unitsNeeded: 1,
    urgency: 'high',
    hospital: 'St. Mary\'s Hospital',
    distance: '2.8 km',
    timeAgo: '15 min ago',
    location: 'Westside District',
    compatible: false,
  },
  {
    id: '3',
    patientName: 'Emma Wilson',
    bloodType: 'O-',
    unitsNeeded: 3,
    urgency: 'critical',
    hospital: 'Central Medical Center',
    distance: '3.5 km',
    timeAgo: '22 min ago',
    location: 'Central District',
    compatible: true,
  },
  {
    id: '4',
    patientName: 'David Martinez',
    bloodType: 'B+',
    unitsNeeded: 2,
    urgency: 'normal',
    hospital: 'Riverside Hospital',
    distance: '5.1 km',
    timeAgo: '1 hour ago',
    location: 'Riverside Area',
    compatible: false,
  },
];

export function DonorDashboard({ user }: DonorDashboardProps) {
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 max-w-md w-full text-center">
          <AlertCircle className="w-12 h-12 text-orange-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Please Login</h2>
          <p className="text-gray-600">You need to be logged in to access the donor dashboard.</p>
        </div>
      </div>
    );
  }

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'normal':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Stats */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Donor Dashboard</h1>
              <p className="text-gray-600 mt-1">Welcome back, {user.name}!</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-sm text-gray-600">Your Blood Type</div>
                <div className="text-2xl font-bold text-red-600">{user.bloodType || 'Not Set'}</div>
              </div>
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center">
                <Droplet className="w-8 h-8 text-white" fill="white" />
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-red-700 font-medium">Active Requests</div>
                  <div className="text-2xl font-bold text-red-900">12</div>
                </div>
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-green-700 font-medium">Lives Saved</div>
                  <div className="text-2xl font-bold text-green-900">8</div>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-blue-700 font-medium">Total Donations</div>
                  <div className="text-2xl font-bold text-blue-900">15</div>
                </div>
                <Droplet className="w-8 h-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-purple-700 font-medium">Next Eligible</div>
                  <div className="text-lg font-bold text-purple-900">45 days</div>
                </div>
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content - Blood Requests */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900">Nearby Emergency Requests</h2>
              <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                <Navigation className="w-4 h-4" />
                View Map
              </button>
            </div>

            {/* Request Cards */}
            {mockRequests.map((request) => (
              <div
                key={request.id}
                className={`bg-white rounded-lg shadow-md border-2 transition-all hover:shadow-lg ${
                  request.compatible ? 'border-red-200' : 'border-gray-200'
                }`}
              >
                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold text-gray-900 text-lg">{request.patientName}</h3>
                        {request.compatible && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                            Compatible
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{request.distance} away</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{request.timeAgo}</span>
                        </div>
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 text-xs font-semibold rounded-full border uppercase ${getUrgencyColor(
                        request.urgency
                      )}`}
                    >
                      {request.urgency}
                    </span>
                  </div>

                  {/* Details */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Blood Type</div>
                      <div className="font-semibold text-gray-900 flex items-center gap-1">
                        <Droplet className="w-4 h-4 text-red-600" />
                        {request.bloodType}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Units Needed</div>
                      <div className="font-semibold text-gray-900">{request.unitsNeeded} units</div>
                    </div>
                    <div className="col-span-2">
                      <div className="text-xs text-gray-600 mb-1">Hospital</div>
                      <div className="font-semibold text-gray-900">{request.hospital}</div>
                    </div>
                  </div>

                  {/* Location */}
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
                    <MapPin className="w-4 h-4" />
                    <span>{request.location}</span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center justify-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      Accept Request
                    </button>
                    <button className="px-4 py-3 border border-gray-300 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                      <Phone className="w-5 h-5" />
                      Contact
                    </button>
                    <button className="px-4 py-3 border border-gray-300 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                      <Navigation className="w-5 h-5" />
                      Directions
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Map Preview */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-gradient-to-r from-red-600 to-red-700 text-white">
                <h3 className="font-semibold flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Live Map View
                </h3>
              </div>
              <div className="aspect-square bg-gray-200 relative">
                {/* Mock Map */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Interactive map would appear here</p>
                    <button className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700">
                      Open Full Map
                    </button>
                  </div>
                </div>
                {/* Mock Markers */}
                <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                <div className="absolute top-2/3 right-1/3 w-3 h-3 bg-orange-600 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* Donation History */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Recent Donations</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900">2 units donated</div>
                    <div className="text-xs text-gray-600">City Hospital - Dec 15, 2025</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900">1 unit donated</div>
                    <div className="text-xs text-gray-600">St. Mary's - Nov 8, 2025</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Eligibility Info */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2">Donation Eligibility</h3>
              <p className="text-sm text-blue-800 mb-3">
                You can donate again in <strong>45 days</strong>
              </p>
              <div className="bg-white rounded-full h-2 overflow-hidden">
                <div className="bg-blue-600 h-full" style={{ width: '65%' }}></div>
              </div>
              <p className="text-xs text-blue-700 mt-2">65% time elapsed since last donation</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
