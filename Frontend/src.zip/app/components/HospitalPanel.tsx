import { CheckCircle, XCircle, Clock, Users, Droplet, Activity, Search, Filter } from 'lucide-react';

interface User {
  name: string;
  role: 'donor' | 'requestor' | 'hospital' | null;
  verified: boolean;
  bloodType?: string;
}

interface HospitalPanelProps {
  user: User | null;
}

interface PendingRequest {
  id: string;
  patientName: string;
  bloodType: string;
  unitsNeeded: number;
  urgency: 'critical' | 'high' | 'normal';
  requestor: string;
  submittedAt: string;
  documentsUploaded: boolean;
}

interface PendingDonor {
  id: string;
  name: string;
  bloodType: string;
  lastDonation: string;
  totalDonations: number;
  documentsUploaded: boolean;
}

const mockPendingRequests: PendingRequest[] = [
  {
    id: 'REQ-001',
    patientName: 'John Smith',
    bloodType: 'O+',
    unitsNeeded: 2,
    urgency: 'critical',
    requestor: 'Sarah Johnson',
    submittedAt: '10 min ago',
    documentsUploaded: true,
  },
  {
    id: 'REQ-002',
    patientName: 'Emily Davis',
    bloodType: 'A-',
    unitsNeeded: 1,
    urgency: 'high',
    requestor: 'Michael Chen',
    submittedAt: '25 min ago',
    documentsUploaded: true,
  },
];

const mockPendingDonors: PendingDonor[] = [
  {
    id: 'DON-001',
    name: 'Alex Thompson',
    bloodType: 'B+',
    lastDonation: 'Never',
    totalDonations: 0,
    documentsUploaded: true,
  },
  {
    id: 'DON-002',
    name: 'Maria Garcia',
    bloodType: 'O-',
    lastDonation: 'Never',
    totalDonations: 0,
    documentsUploaded: false,
  },
];

export function HospitalPanel({ user }: HospitalPanelProps) {
  if (!user || user.role !== 'hospital') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 max-w-md w-full text-center">
          <XCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600">This area is only accessible to authorized hospital staff.</p>
        </div>
      </div>
    );
  }

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'normal':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Hospital Panel</h1>
              <p className="text-gray-600 mt-1">{user.name}</p>
            </div>
            <div className="flex items-center gap-2">
              {user.verified && (
                <span className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-lg border border-green-300">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-semibold">Verified Organization</span>
                </span>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-red-700 font-medium">Pending Verifications</div>
                  <div className="text-2xl font-bold text-red-900">4</div>
                </div>
                <Clock className="w-8 h-8 text-red-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-green-700 font-medium">Active Donations</div>
                  <div className="text-2xl font-bold text-green-900">12</div>
                </div>
                <Activity className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-blue-700 font-medium">Total This Month</div>
                  <div className="text-2xl font-bold text-blue-900">156</div>
                </div>
                <Droplet className="w-8 h-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-purple-700 font-medium">Registered Donors</div>
                  <div className="text-2xl font-bold text-purple-900">1,234</div>
                </div>
                <Users className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Pending Blood Requests */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900">Pending Blood Requests</h2>
              <button className="flex items-center gap-2 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Filter className="w-4 h-4" />
                Filter
              </button>
            </div>

            <div className="space-y-4">
              {mockPendingRequests.map((request) => (
                <div key={request.id} className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold text-gray-900">{request.patientName}</h3>
                        {request.documentsUploaded && (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        Requested by: {request.requestor} • {request.submittedAt}
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 text-xs font-semibold rounded-full border uppercase ${getUrgencyColor(
                        request.urgency
                      )}`}
                    >
                      {request.urgency}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4 p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Blood Type</div>
                      <div className="font-semibold text-gray-900 flex items-center gap-1">
                        <Droplet className="w-4 h-4 text-red-600" />
                        {request.bloodType}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Units</div>
                      <div className="font-semibold text-gray-900">{request.unitsNeeded}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-600 mb-1">ID</div>
                      <div className="font-semibold text-gray-900 text-xs">{request.id}</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors text-sm flex items-center justify-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      Approve
                    </button>
                    <button className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-200 transition-colors text-sm">
                      Review Docs
                    </button>
                    <button className="px-4 py-2 border border-red-300 text-red-600 rounded-lg font-semibold hover:bg-red-50 transition-colors text-sm flex items-center gap-2">
                      <XCircle className="w-4 h-4" />
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pending Donor Verifications */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900">Pending Donor Verifications</h2>
              <button className="flex items-center gap-2 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Search className="w-4 h-4" />
                Search
              </button>
            </div>

            <div className="space-y-4">
              {mockPendingDonors.map((donor) => (
                <div key={donor.id} className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold text-gray-900">{donor.name}</h3>
                        {donor.documentsUploaded ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <Clock className="w-4 h-4 text-orange-600" />
                        )}
                      </div>
                      <div className="text-sm text-gray-600">ID: {donor.id}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Droplet className="w-5 h-5 text-red-600" fill="currentColor" />
                      <span className="font-bold text-gray-900">{donor.bloodType}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Last Donation</div>
                      <div className="font-semibold text-gray-900 text-sm">{donor.lastDonation}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-600 mb-1">Total Donations</div>
                      <div className="font-semibold text-gray-900 text-sm">{donor.totalDonations}</div>
                    </div>
                  </div>

                  {!donor.documentsUploaded && (
                    <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <p className="text-sm text-orange-800">
                        ⚠️ Waiting for document upload
                      </p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      className={`flex-1 px-4 py-2 rounded-lg font-semibold transition-colors text-sm flex items-center justify-center gap-2 ${
                        donor.documentsUploaded
                          ? 'bg-green-600 text-white hover:bg-green-700'
                          : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      }`}
                      disabled={!donor.documentsUploaded}
                    >
                      <CheckCircle className="w-4 h-4" />
                      Verify Donor
                    </button>
                    <button className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-200 transition-colors text-sm">
                      View Profile
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Recent Activity</h2>
          <div className="bg-white rounded-lg shadow-md divide-y divide-gray-200">
            <div className="p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-900">Blood request approved</div>
                  <div className="text-sm text-gray-600">REQ-2024-089 for patient Emma Wilson</div>
                </div>
                <div className="text-sm text-gray-500">5 min ago</div>
              </div>
            </div>

            <div className="p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-900">New donor verified</div>
                  <div className="text-sm text-gray-600">Alex Thompson (B+) added to network</div>
                </div>
                <div className="text-sm text-gray-500">12 min ago</div>
              </div>
            </div>

            <div className="p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Droplet className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-900">Donation completed</div>
                  <div className="text-sm text-gray-600">2 units of O+ collected from Sarah Chen</div>
                </div>
                <div className="text-sm text-gray-500">1 hour ago</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
