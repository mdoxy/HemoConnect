import { useState } from 'react';
import { Header } from '@/app/components/Header';
import { LandingPage } from '@/app/components/LandingPage';
import { FindBlood } from '@/app/components/FindBlood';
import { Education } from '@/app/components/Education';
import { DonorDashboard } from '@/app/components/DonorDashboard';
import { RequestorDashboard } from '@/app/components/RequestorDashboard';
import { HospitalPanel } from '@/app/components/HospitalPanel';
import { Profile } from '@/app/components/Profile';
import { Notifications } from '@/app/components/Notifications';
import { LoginModal } from '@/app/components/LoginModal';
import { SignupModal } from '@/app/components/SignupModal';
import { Footer } from '@/app/components/Footer';

type Page = 'home' | 'find-blood' | 'request-blood' | 'become-donor' | 'hospitals' | 'education' | 'donor-dashboard' | 'requestor-dashboard' | 'hospital-panel' | 'profile' | 'notifications';

type UserRole = 'donor' | 'requestor' | 'hospital' | null;

interface User {
  name: string;
  role: UserRole;
  verified: boolean;
  bloodType?: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showSignupModal, setShowSignupModal] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setShowLoginModal(false);
    // Navigate to appropriate dashboard based on role
    if (userData.role === 'donor') {
      setCurrentPage('donor-dashboard');
    } else if (userData.role === 'requestor') {
      setCurrentPage('requestor-dashboard');
    } else if (userData.role === 'hospital') {
      setCurrentPage('hospital-panel');
    }
  };

  const handleSignup = (userData: User) => {
    setUser(userData);
    setShowSignupModal(false);
    // Navigate to appropriate dashboard based on role
    if (userData.role === 'donor') {
      setCurrentPage('donor-dashboard');
    } else if (userData.role === 'requestor') {
      setCurrentPage('requestor-dashboard');
    } else if (userData.role === 'hospital') {
      setCurrentPage('hospital-panel');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('home');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        user={user}
        onLogin={() => setShowLoginModal(true)}
        onSignup={() => setShowSignupModal(true)}
        onLogout={handleLogout}
      />
      
      <main className="flex-1">
        {currentPage === 'home' && <LandingPage onNavigate={setCurrentPage} onLogin={() => setShowLoginModal(true)} />}
        {currentPage === 'find-blood' && <FindBlood />}
        {currentPage === 'request-blood' && <RequestorDashboard user={user} />}
        {currentPage === 'become-donor' && <DonorDashboard user={user} />}
        {currentPage === 'hospitals' && <HospitalPanel user={user} />}
        {currentPage === 'education' && <Education />}
        {currentPage === 'donor-dashboard' && <DonorDashboard user={user} />}
        {currentPage === 'requestor-dashboard' && <RequestorDashboard user={user} />}
        {currentPage === 'hospital-panel' && <HospitalPanel user={user} />}
        {currentPage === 'profile' && <Profile user={user} />}
        {currentPage === 'notifications' && <Notifications />}
      </main>
      
      <Footer />

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLogin={handleLogin}
          onSwitchToSignup={() => {
            setShowLoginModal(false);
            setShowSignupModal(true);
          }}
        />
      )}

      {showSignupModal && (
        <SignupModal
          onClose={() => setShowSignupModal(false)}
          onSignup={handleSignup}
          onSwitchToLogin={() => {
            setShowSignupModal(false);
            setShowLoginModal(true);
          }}
        />
      )}
    </div>
  );
}
